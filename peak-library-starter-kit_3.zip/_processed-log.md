# Processed log

One row per call file written by the PEAK call intel skill. The skill reads this to know what has already been done, so please do not delete rows. To reprocess a file on purpose, delete its row and its call file, then run the skill again.

| source_file | call_file | firm_slug | call_date | processed_on |
|---|---|---|---|---|
