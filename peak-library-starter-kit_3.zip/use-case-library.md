# Use case library

Alvaro's catalogue of the use cases PEAK sells. The call intel skill matches what clients say against the names here, and flags anything new. The roll-up lists which of these clients have raised, and which they have not.

How to keep it: one line per sub use case, under its workflow. Keep names short and stable (the skill uses them word for word in call files). Add a line when the roll-up's "new use case candidates" shows something worth keeping; delete nothing, mark retired ones `(retired)`.

Format: `- **<Sub use case name>**: <one line on what it is> | datasets: <MCP datasets it needs> | strategies: <buyout, growth-equity, ... or all>`

## Origination
- **Target screening on financial health**: shortlist private companies in a sector or region by financials and default risk | datasets: financials, edf-x | strategies: all
- **Sector and market mapping**: who is in a sector, who owns whom, where the independents are | datasets: ownership-structure, financials | strategies: all

## Issuer and sector research
- **Comparable companies**: peers and benchmarks for a target, including private peers | datasets: financials | strategies: all
- **Sector outlook and credit view**: Moody's research and sector outlooks on a target's market | datasets: ratings-research | strategies: all

## Financial DD
- **Ownership and group structure mapping**: subsidiaries, ultimate owners and holding structures on a target, including carve-outs | datasets: ownership-structure | strategies: all
- **Customer and supplier health**: default risk of a target's key customers and suppliers | datasets: edf-x, financials | strategies: all
- **Commercial due diligence support**: market size, competitors and their financials for the CDD | datasets: financials, news | strategies: all

## Management DD
- **Directors and managers check**: who runs the target and what else they run or ran | datasets: ownership-structure, screening-kyc | strategies: all

## Underwriting
- **Debt capacity and credit view**: how a lender would see the target, ratings and PD on the structure | datasets: edf-x, ratings-research | strategies: buyout, growth-buyout

## Investment memo
- **Data straight into the IC memo**: financials, structure charts and risk views pulled into the memo draft | datasets: financials, ownership-structure, edf-x | strategies: all

## Portfolio monitoring
- **Portfolio company customer and supplier monitoring**: regular PD check on the largest customers and suppliers of portfolio companies | datasets: edf-x | strategies: all
- **Portfolio news watch**: news on portfolio companies and their markets | datasets: news | strategies: all

## Other
- **KYC on co-investors and counterparties**: ownership and shell company checks | datasets: ownership-structure, screening-kyc | strategies: all
