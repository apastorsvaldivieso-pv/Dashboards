---
type: call
date: YYYY-MM-DD
firm: <canonical name from the campaign spreadsheet>
firm_slug: <slug>
firm_tier: <tier-1 | tier-2 | "">
pe_strategy: <buyout | growth-equity | growth-buyout | minority-structured-equity | venture | secondaries | other | "">
size: <lower-mid-market | mid-market | large-cap | "">
sector_focus: <generalist | "specialist: <sectors>" | "">
team_met: "<fund or team, or empty>"
stage: <first-call | demo | trial | commercial | closed-won | closed-lost>
input_type: <transcript | summary | raw-notes | email>
datasets_discussed: [<datasets from tags.md section 7>]
source_file: "<path to the source file, relative to the library root, or 'pasted in chat on YYYY-MM-DD'>"
attendees:
  - name: <name or "unknown">
    title: <exact title or "unknown">
    persona: <persona>
    workflows: [<workflows the input shows they cover, or empty>]
    decision_maker: <true | false | unknown>
flags: [<flags, or empty>]
---

# <Firm> | <YYYY-MM-DD> | <stage>

## Key points
- <detailed point a stranger would understand without the source>

## Questions they asked
- "<question>" | asked by: <title> | theme: <short theme> | evidence: <verbatim | paraphrased | noted>

## Objections
- "<quote or paraphrase>" | category: <category> | raised by: <title> | decision maker: <true | false | unknown> | status: <open | resolved | deferred> | source: <client_direct | client_reported | client_group> | evidence: <verbatim | paraphrased | noted> | reply: <optional: what Moody's answered, in a few words>

## Product feedback (by MCP dataset)
- <dataset> | <positive | negative | mixed> | <what was said, specific> | by: <title, when known>

## What landed
- <use case, data point or demo moment the client clearly reacted to, and the reaction> | by: <title, when known>

## Competitors and alternatives mentioned
- <vendor or "in-house"> | <product, team or stack> | <what was said> | <positive | negative | mixed>

## Tech stack
- <name> | <deployed | evaluating | mentioned | rejected> | <context>

## Workflows to improve
- <workflow tag, or other> | <what it is, in a few words> | <current pain> | <desired state>

## Budget and decision process
- <owner, process, timeline, stakeholders, procurement>

## Engagement
Temperature: <hot | warm | lukewarm | cold | unknown> | Momentum: <building | flat | declining | unknown>
- <signal moment> | <quote or paraphrase>

## Next steps
- <step> | <owner> | <due or "tbc">

## Transcription corrections
- <heard> | <corrected to> | <context>
