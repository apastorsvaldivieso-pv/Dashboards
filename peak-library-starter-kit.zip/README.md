# PEAK library: read me first

This folder is the PEAK team's shared memory of what private equity clients tell us: their questions, their objections, what they like about the Moody's MCP and what falls short. Every call, set of notes or client email becomes one small file. Those files are then summarised into views the team can use for outbound, meeting prep, demos and management updates.

## Before anything else: who can see this folder

Keep this folder restricted to Alvaro and the person running the process until the compliance check is done. Only after that check should it be shared with the wider PEAK team or connected to Copilot agents. The files name clients and record what they said.

## How it works

There are two kinds of files.

- **Call files are receipts.** One per call, email or set of notes, written once and never changed. They live in `calls/call-files`.
- **Summary files are the bank statement.** Personas, objections, questions, product feedback and competition from calls are rebuilt from all the call files every two weeks or month. Nobody edits them by hand: the next rebuild would overwrite the edit. If something in a summary looks wrong, the fix goes in the evidence, not the summary.

Two skills do the work:

| Skill | What it does | How often |
|---|---|---|
| PEAK call intel | Reads one transcript, summary, set of notes or client email and writes one call file | After each call, or as a daily or weekly routine |
| PEAK library roll-up | Reads all the call files, the email campaign file and the competition research, and rebuilds the summary files | Every two weeks or monthly, or before a big meeting |

## Adding a new call or client email

1. Save the transcript, summary, notes or email (as a text, Word or PDF file) into `calls/inbox`. Name it with the date and firm if you can, for example `2026-11-04 Astorg first call.txt`.
2. Ask Claude: "process the inbox" (or, for one file, "process this call").
3. Claude writes one call file per call into `calls/call-files` and adds a row to `_processed-log.md`. It tells you anything it flagged.

In the Claude app (where Claude cannot save to SharePoint), Claude gives you the call file to download and a line to paste into `_processed-log.md`. Save the file into `calls/call-files` and paste the line at the bottom of the log.

## What to check after each run

- Read the two or three lines Claude reports. Anything flagged (for example "firm not in campaign spreadsheet") is worth a look.
- Open one call file now and then. If it says a client raised something you know Moody's said, tell Alvaro.

## Folder guide

| Folder | What is in it | Who changes it |
|---|---|---|
| calls | Original transcripts, summaries and notes | People |
| calls/inbox | New calls and client emails waiting to be processed | People |
| calls/call-files | One call file per call, plus `_processed-log.md` | Skill 1 only |
| personas | One file per type of client person | Roll-up only (`_existing-view` holds Alvaro's original material) |
| objections-questions | Objections and questions across all calls | Roll-up only (`_existing-view` as above) |
| product-feedback | Feedback per MCP dataset | Roll-up only |
| competition | `from-calls.md` (roll-up) and Alvaro's own research (by hand) | See left |
| outbound | The email campaign file | The email team |
| research | One file per firm, written before big meetings | Prep agent |
| weekly-summary | What changed, management summary | Roll-up only |
| data-points, prompt-library | What our data covers, ready-made prompts | Alvaro |
| Campaign-PE-firms-Europe.xlsx | The firm list, with tier, PE strategy, size and sector where filled | Alvaro |

## Rules that keep the library trustworthy

- Only what the client said goes in. What Moody's said is never logged as client feedback.
- Nothing is invented: no made-up quotes, no guessed facts. "None captured" means someone looked and found nothing.
- Same labels every time, from fixed lists, so counting works.
- Client views and our own research stay in separate files.
