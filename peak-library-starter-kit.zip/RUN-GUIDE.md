# PEAK library: run guide

Four jobs, in plain steps. Each one takes a few minutes of your time; Claude does the reading.

**Before the first run:** keep the Private Equity folder restricted to Alvaro and you until the compliance check is done. Do not share it with the wider team or connect Copilot agents to it before then.

## How to start Claude Code in the right place

Open Claude Code inside the Private Equity folder (the one with `calls`, `personas` and the campaign spreadsheet). Claude then knows where the library is and you never type a folder path.

Pick the model when you start: **Opus** for the backfill and the roll-up, **Sonnet** for everyday calls.

## 1. Setup (once)

Say: **"set up the PEAK library"**

Claude creates `calls/inbox` and `calls/call-files`, puts this guide, the README and an empty log in place, and tells you which existing files to move into the `_existing-view` folders. Move those files yourself.

**Check:** the folders exist and `calls/call-files/_processed-log.md` is there.

## 2. Backfill the old calls (once)

Say: **"backfill the calls"** (use Opus)

Claude works through every transcript, summary and note in `calls`, one at a time, writing one call file per call into `calls/call-files`. With 50 or 60 calls this takes a while. If it stops, say the same thing again: it picks up where it left off.

**Check:** read the report at the end. Note any firm it says is missing from the campaign spreadsheet, and any "contradicts spreadsheet" or "call says" flags, and pass them to Alvaro so he can update the spreadsheet.

## 3. New calls and client emails (every day or week)

1. Save the transcript, summary, notes or client email into `calls/inbox`. A date and firm in the file name helps: `2026-11-04 Astorg first call.txt`.
2. Say: **"process the inbox"** (Sonnet is fine).

**Check:** read Claude's two or three lines per file. Now and then open a call file: if it says a client raised something you know Moody's said, tell Alvaro.

**In the Claude app instead:** attach or paste the call and say "process this call". Claude gives you a file and one line of text. Save the file into `calls/call-files` and paste the line at the bottom of `calls/call-files/_processed-log.md`.

## 4. The roll-up (every two weeks or month, or before a big meeting)

Say: **"run the roll-up"** (use Opus)

Claude rebuilds the persona, objection, question, product feedback and competition files from all the call files, the email campaign file in `outbound` and Alvaro's competitor research.

**Check:** open `weekly-summary/what-changed.md`. It is one page and the only thing you must read. If it lists "theme changes" or "needs a look", forward it to Alvaro.

**Never edit** the files the roll-up writes (personas, objections-questions, product-feedback, competition/from-calls.md, weekly-summary). The next roll-up overwrites them. If something looks wrong, the fix belongs in the call file, so tell Alvaro.

## If something goes wrong

- "python not found": the checks still run by hand for single calls. The roll-up needs Python; run it from the Claude app with the files attached, or ask IT.
- A call was processed twice: delete the newer call file and its row in `_processed-log.md`.
- To redo a call on purpose: delete its call file and its row in the log, then process it again.
